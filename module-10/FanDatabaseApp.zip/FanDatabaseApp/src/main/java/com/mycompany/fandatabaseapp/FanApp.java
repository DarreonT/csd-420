/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author darre
 */
public class FanApp {
    
}
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class FanApp extends Application {

    private final FanDAO dao = new FanDAO();

    private final TextField idInput = new TextField();
    private final TextField idDisplay = new TextField();
    private final TextField firstNameField = new TextField();
    private final TextField lastNameField = new TextField();
    private final TextField favoriteTeamField = new TextField();
    private final Label status = new Label("Ready.");

    @Override
    public void start(Stage stage) {
        idDisplay.setEditable(false);

        Button displayBtn = new Button("Display");
        Button updateBtn = new Button("Update");

        displayBtn.setOnAction(e -> onDisplay());
        updateBtn.setOnAction(e -> onUpdate());

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(15));
        grid.setHgap(10);
        grid.setVgap(10);

        int r = 0;
        grid.add(new Label("Enter ID:"), 0, r);
        grid.add(idInput, 1, r);
        grid.add(displayBtn, 2, r);

        r++;
        grid.add(new Label("ID:"), 0, r);
        grid.add(idDisplay, 1, r);

        r++;
        grid.add(new Label("First Name:"), 0, r);
        grid.add(firstNameField, 1, r);

        r++;
        grid.add(new Label("Last Name:"), 0, r);
        grid.add(lastNameField, 1, r);

        r++;
        grid.add(new Label("Favorite Team:"), 0, r);
        grid.add(favoriteTeamField, 1, r);

        r++;
        grid.add(updateBtn, 1, r);

        r++;
        grid.add(status, 0, r, 3, 1);

        stage.setTitle("Fans Viewer/Updater");
        stage.setScene(new Scene(grid, 600, 280));
        stage.show();
    }

    private void onDisplay() {
        try {
            int id = Integer.parseInt(idInput.getText().trim());
            Fan fan = dao.getFanById(id);

            if (fan == null) {
                clearFields();
                status.setText("No record found for ID " + id);
                return;
            }

            idDisplay.setText(String.valueOf(fan.getId()));
            firstNameField.setText(fan.getFirstName());
            lastNameField.setText(fan.getLastName());
            favoriteTeamField.setText(fan.getFavoriteTeam());

            status.setText("Displayed ID " + id);
        } catch (NumberFormatException ex) {
            status.setText("ID must be a number.");
        } catch (Exception ex) {
            status.setText("Display error: " + ex.getMessage());
        }
    }

    private void onUpdate() {
        try {
            if (idDisplay.getText().isBlank()) {
                status.setText("Display a record first.");
                return;
            }

            int id = Integer.parseInt(idDisplay.getText().trim());
            Fan fan = new Fan(id,
                firstNameField.getText().trim(),
                lastNameField.getText().trim(),
                favoriteTeamField.getText().trim()
            );

            boolean ok = dao.updateFan(fan);
            status.setText(ok ? "Updated ID " + id : "Update failed for ID " + id);

        } catch (Exception ex) {
            status.setText("Update error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        idDisplay.clear();
        firstNameField.clear();
        lastNameField.clear();
        favoriteTeamField.clear();
    }

    public static void main(String[] args) {
        launch(args);
    }
}