/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fandatabaseapp;

/**
 *
 * @author darre
 */
public class FanDatabaseApp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
