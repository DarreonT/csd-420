/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author darre
 */
public class FanTests {
    
}
public class FanTests {
    public static void main(String[] args) {
        FanDAO dao = new FanDAO();

        try {
            System.out.println("TEST 1: getFanById(1)");
            Fan f1 = dao.getFanById(1);
            System.out.println(f1 != null ? "PASS: " + f1.getFirstName() : "FAIL: Not found");

            System.out.println("\nTEST 2: updateFan(2) change + restore");
            Fan f2 = dao.getFanById(2);

            if (f2 == null) {
                System.out.println("FAIL: ID 2 not found");
                return;
            }

            String oldTeam = f2.getFavoriteTeam();
            f2.setFavoriteTeam("TEST_TEAM");

            boolean updated = dao.updateFan(f2);
            Fan after = dao.getFanById(2);

            boolean changed = after != null && "TEST_TEAM".equals(after.getFavoriteTeam());

            // restore original
            f2.setFavoriteTeam(oldTeam);
            dao.updateFan(f2);

            System.out.println(updated && changed ? "PASS: Update worked" : "FAIL: Update failed");

        } catch (Exception e) {
            System.out.println("FAIL: " + e.getMessage());
        }
    }
}